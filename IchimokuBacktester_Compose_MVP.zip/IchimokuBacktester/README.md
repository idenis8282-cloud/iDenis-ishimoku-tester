# Ichimoku Backtester (Android)

Fixed theme (Material3). Compose MVP for Binance Futures klines + basic backtest.
