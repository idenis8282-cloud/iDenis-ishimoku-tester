# Ichimoku Backtester (Android)

Compose MVP: load 5m klines from Binance Futures, generate signals, run a simple backtest.
