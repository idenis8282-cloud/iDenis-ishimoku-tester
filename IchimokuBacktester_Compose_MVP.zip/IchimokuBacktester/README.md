# Ichimoku Backtester (Android)

ZIP build for GitHub Actions (no wrapper). Uses platform theme to avoid AAPT theme issues.
